package example

class DroneCrashException : Exception() {
}
