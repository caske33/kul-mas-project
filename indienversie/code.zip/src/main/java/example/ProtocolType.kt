package example

enum class ProtocolType {
    CONTRACT_NET,
    CONTRACT_NET_CONFIRMATION,
    DYNAMIC_CONTRACT_NET
}